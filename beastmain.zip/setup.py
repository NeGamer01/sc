import os
print("[+] Installing requierments ...")
os.system('pip install telethon==1.24.0')
os.system('pip install colorama==0.4.3')

print("[+] setup complete !")
print("[+] now you can run any tool !")
input('\n Press enter to exit...')
